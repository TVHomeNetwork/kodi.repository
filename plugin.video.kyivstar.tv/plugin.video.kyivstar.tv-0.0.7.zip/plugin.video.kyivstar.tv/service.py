from resources.lib.kyivstar_service import KyivstarService

service = KyivstarService()

if __name__ == '__main__':
    service.run()
